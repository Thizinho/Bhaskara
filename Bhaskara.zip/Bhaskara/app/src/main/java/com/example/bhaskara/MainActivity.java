package com.example.bhaskara;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText editTextA, editTextB, editTextC;
    private TextView resultTextView;
    private Button calculateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextA = findViewById(R.id.editTextA);
        editTextB = findViewById(R.id.editTextB);
        editTextC = findViewById(R.id.editTextC);
        resultTextView = findViewById(R.id.resultTextView);
        calculateButton = findViewById(R.id.calculateButton);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateBhaskara();
            }
        });
    }

    private void calculateBhaskara() {
        double a = Double.parseDouble(editTextA.getText().toString());
        double b = Double.parseDouble(editTextB.getText().toString());
        double c = Double.parseDouble(editTextC.getText().toString());

        double discriminant = b * b - 4 * a * c;

        if (discriminant > 0) {
            double root1 = (-b + Math.sqrt(discriminant)) / (2 * a);
            double root2 = (-b - Math.sqrt(discriminant)) / (2 * a);
            resultTextView.setText("As raízes da equação são reais e diferentes:\nRaiz 1: " + root1 + "\nRaiz 2: " + root2);
        } else if (discriminant == 0) {
            double root = -b / (2 * a);
            resultTextView.setText("A raiz da equação é real e igual:\nRaiz: " + root);
        } else {
            double realPart = -b / (2 * a);
            double imaginaryPart = Math.sqrt(-discriminant) / (2 * a);
            resultTextView.setText("As raízes da equação são complexas e conjugadas:\nRaiz 1: " + realPart + " + " + imaginaryPart + "i\nRaiz 2: " + realPart + " - " + imaginaryPart + "i");
        }
    }
}
